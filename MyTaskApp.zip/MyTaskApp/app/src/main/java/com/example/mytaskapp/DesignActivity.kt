package com.example.mytaskapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DesignActivity:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

}