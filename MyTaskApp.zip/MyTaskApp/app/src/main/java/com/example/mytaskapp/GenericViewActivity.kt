package com.example.mytaskapp

import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setMargins
import com.example.mytaskapp.databinding.ActivityGenericBinding

class GenericViewActivity:AppCompatActivity() {

    lateinit var binding : ActivityGenericBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGenericBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val input=intent.getStringExtra("KEY")
        val inputbefore=input?.substringBefore('~')
        val inputafter=input?.substringAfter('~')

        when(inputbefore){
            "T"->textViews()
            "C"->checkBoxes()
            "R" ->radioButtons()
        }

    }
    private fun textViews(){
        var textlayout=LinearLayout(this)
        textlayout.orientation=LinearLayout.HORIZONTAL
       binding.linearLayout.addView(textlayout)
        var textView=TextView(this)
        textView.setText("Text")
        setTextView(textView)
        textlayout.addView(textView)

    }
    private fun radioButtons(){
        var rd=RadioGroup(this)
        rd.orientation=LinearLayout.HORIZONTAL
       binding. linearLayout.addView(rd)
        var radioButton = RadioButton(this)
        radioButton.setText("RadioButton")
        rd.addView(radioButton)
        setRadioButton(radioButton)

    }

    private fun checkBoxes(){
        var checkbox=LinearLayout(this)
        checkbox.orientation=LinearLayout.HORIZONTAL
        binding.linearLayout.addView(checkbox)
        val checkBox = CheckBox(this);
        checkBox.setText("CheckBox")
        setCheckBox(checkBox)
        checkbox.addView(checkBox)
    }

    private fun setTextView(textView: TextView){
        val params=LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(20)
        params.gravity=2
        textView.layoutParams=params
    }
    private fun setRadioButton(radioButton: RadioButton){
        val params=LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(20)
        radioButton.layoutParams=params
    }
    private fun setCheckBox(checkBox: CheckBox){
        val params=LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(20)
        checkBox.layoutParams=params
    }


}